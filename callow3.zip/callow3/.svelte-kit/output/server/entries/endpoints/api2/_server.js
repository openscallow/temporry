import mysql from "mysql2/promise";
async function POST({ request }) {
  let connection;
  const { name, mobile, address, product } = await request.json();
  try {
    connection = await mysql.createConnection({
      host: "callowdatabase.cpam6os8m3nn.ap-south-1.rds.amazonaws.com",
      user: "gautam",
      password: "Gautam404&",
      database: "callowdb"
    });
    const query = "INSERT INTO `order` (name, mobile, address, product) VALUES (?, ?, ?, ?)";
    const [result] = await connection.execute(query, [name, mobile, address, product]);
    return new Response(JSON.stringify({ id: result.insertId }), { status: 201 });
  } catch (error) {
    console.error("Error inserting into the database:", error);
    return new Response(JSON.stringify({ error: "Database insertion failed" }), { status: 500 });
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}
export {
  POST
};
