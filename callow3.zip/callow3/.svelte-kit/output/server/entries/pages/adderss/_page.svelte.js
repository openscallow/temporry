import { c as create_ssr_component, v as validate_component, d as each, a as add_attribute, e as escape } from "../../../chunks/ssr.js";
import { I as Icon } from "../../../chunks/Icon.js";
const Info = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "10" }],
    ["path", { "d": "M12 16v-4" }],
    ["path", { "d": "M12 8h.01" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "info" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const css = {
  code: "#containner.svelte-1h5ymak{width:100%;display:grid;justify-content:center;align-items:center}h3.svelte-1h5ymak{margin-top:10px}input.svelte-1h5ymak{margin-top:10px;border-radius:0.25rem;border:1px solid black;width:calc(100vw - 2rem);padding:0.5rem;font-size:1rem}button.svelte-1h5ymak{width:calc(100vw - 2rem);margin-top:20px;background-color:#1a202c;color:white;padding:12px;border:none;border-radius:4px;font-weight:bold;cursor:pointer}",
  map: `{"version":3,"file":"+page.svelte","sources":["+page.svelte"],"sourcesContent":["<script>\\n    import { Info } from 'lucide-svelte';\\n    let schools = [ \\n        \\"AKSHARJYOTI HIGHER SECONDARY SCHOOL\\", \\n        \\"ANGLO URDU HIGH SCHOOL\\", \\n        \\"ANKUR HIGH SCHOOL\\", \\n        \\"ANKUR VIDHYABHAVAN(H.S.)\\", \\n        \\"ASHADEEP UCCHTAR MADHYAMIK SHALA\\", \\n        \\"ASHADEEP VIDHYALAY\\", \\n        \\"ASPIRE PUBLIC SCHOOL\\", \\n        \\"B.H.KALSARIYA UCHCHATAR MADH. SHALA\\", \\n        \\"BOGHRA AND AGRAWAL HIGHER SECONDARY SCHOOL\\", \\n        \\"C. S. VIDYA BHARTI ENGLISH SCHOOL\\" \\n    ];\\n\\n    function storeUserAddress() {\\n        // Get the input element with class 'address'\\n        const addressInput = document.querySelector('.address');\\n        \\n        // Check if the element exists\\n        if (addressInput) {\\n            // Get the value from the input\\n            const address = addressInput.value.trim();\\n            \\n            // Store the address in localStorage if it's not empty\\n            if (address) {\\n                localStorage.setItem('userAddress', address);\\n                console.log('Address stored successfully');\\n                \\n                // Optionally, you can call checkAddressAndRoute() here to immediately\\n                // handle routing based on the newly stored address\\n                window.location.href = '../MVC';\\n            } else {\\n                console.log('Address is empty, not stored');\\n            }\\n        } else {\\n            console.log('Address input element not found');\\n        }\\n    }\\n\\n\\n<\/script>\\n\\n<div id=\\"containner\\">\\n    <h3>Enter your school name </h3>\\n    <input list=\\"school\\" class=\\"address\\"/>\\n    <datalist id=\\"school\\">\\n        {#each schools as school}\\n            <option>{school}</option>\\n        {/each}window.location.href = '../order';\\n    </datalist>\\n    \\n    <span style=\\"display: flex; align-items: center; margin-top:5px;\\">\\n        <Info style=\\"margin-right: 8px;\\" /> \\n        <span>you can change this information whenever you want</span>\\n      </span>\\n    <button on:click={storeUserAddress}>save</button>\\n</div>\\n\\n<style>\\n    #containner{\\n        width:100%;\\n        display: grid;\\n        justify-content: center;\\n        align-items: center;\\n    }\\n    h3{\\n        margin-top: 10px;\\n    }\\n \\n    input{\\n        margin-top: 10px;\\n        border-radius: 0.25rem;\\n        border: 1px solid black;\\n        width: calc(100vw - 2rem);\\n        padding: 0.5rem;\\n        font-size: 1rem;\\n    }\\n    button{\\n        width: calc(100vw - 2rem);\\n        margin-top: 20px;\\n        background-color: #1a202c;\\n        color: white;\\n        padding: 12px;\\n        border: none;\\n        border-radius: 4px;\\n        font-weight: bold;\\n        cursor: pointer;\\n    }\\n</style>\\n"],"names":[],"mappings":"AA4DI,0BAAW,CACP,MAAM,IAAI,CACV,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MACjB,CACA,iBAAE,CACE,UAAU,CAAE,IAChB,CAEA,oBAAK,CACD,UAAU,CAAE,IAAI,CAChB,aAAa,CAAE,OAAO,CACtB,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,KAAK,CACvB,KAAK,CAAE,KAAK,KAAK,CAAC,CAAC,CAAC,IAAI,CAAC,CACzB,OAAO,CAAE,MAAM,CACf,SAAS,CAAE,IACf,CACA,qBAAM,CACF,KAAK,CAAE,KAAK,KAAK,CAAC,CAAC,CAAC,IAAI,CAAC,CACzB,UAAU,CAAE,IAAI,CAChB,gBAAgB,CAAE,OAAO,CACzB,KAAK,CAAE,KAAK,CACZ,OAAO,CAAE,IAAI,CACb,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,WAAW,CAAE,IAAI,CACjB,MAAM,CAAE,OACZ"}`
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let schools = [
    "AKSHARJYOTI HIGHER SECONDARY SCHOOL",
    "ANGLO URDU HIGH SCHOOL",
    "ANKUR HIGH SCHOOL",
    "ANKUR VIDHYABHAVAN(H.S.)",
    "ASHADEEP UCCHTAR MADHYAMIK SHALA",
    "ASHADEEP VIDHYALAY",
    "ASPIRE PUBLIC SCHOOL",
    "B.H.KALSARIYA UCHCHATAR MADH. SHALA",
    "BOGHRA AND AGRAWAL HIGHER SECONDARY SCHOOL",
    "C. S. VIDYA BHARTI ENGLISH SCHOOL"
  ];
  $$result.css.add(css);
  return `<div id="containner" class="svelte-1h5ymak"><h3 class="svelte-1h5ymak" data-svelte-h="svelte-15ec0ec">Enter your school name</h3> <input list="school" class="address svelte-1h5ymak"> <datalist id="school">${each(schools, (school) => {
    return `<option${add_attribute("value", school, 0)}>${escape(school)}</option> `;
  })}window.location.href = &#39;../order&#39;;</datalist> <span style="display: flex; align-items: center; margin-top:5px;">${validate_component(Info, "Info").$$render($$result, { style: "margin-right: 8px;" }, {}, {})} <span data-svelte-h="svelte-135us86">you can change this information whenever you want</span></span> <button class="svelte-1h5ymak" data-svelte-h="svelte-gd84sj">save</button> </div>`;
});
export {
  Page as default
};
