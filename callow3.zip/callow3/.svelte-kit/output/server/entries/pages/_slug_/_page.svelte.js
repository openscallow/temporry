import { c as create_ssr_component, b as subscribe, a as add_attribute, e as escape, d as each } from "../../../chunks/ssr.js";
import { p as page } from "../../../chunks/stores.js";
import { p as productDatabase } from "../../../chunks/product.js";
/* empty css                  */
const minus = "data:image/svg+xml,%3csvg%20width='12'%20height='4'%20xmlns='http://www.w3.org/2000/svg'%20xmlns:xlink='http://www.w3.org/1999/xlink'%3e%3cdefs%3e%3cpath%20d='M11.357%203.332A.641.641%200%200%200%2012%202.69V.643A.641.641%200%200%200%2011.357%200H.643A.641.641%200%200%200%200%20.643v2.046c0%20.357.287.643.643.643h10.714Z'%20id='a'/%3e%3c/defs%3e%3cuse%20fill='%23FF7E1B'%20fill-rule='nonzero'%20xlink:href='%23a'/%3e%3c/svg%3e";
const plus = "data:image/svg+xml,%3csvg%20width='12'%20height='12'%20xmlns='http://www.w3.org/2000/svg'%20xmlns:xlink='http://www.w3.org/1999/xlink'%3e%3cdefs%3e%3cpath%20d='M12%207.023V4.977a.641.641%200%200%200-.643-.643h-3.69V.643A.641.641%200%200%200%207.022%200H4.977a.641.641%200%200%200-.643.643v3.69H.643A.641.641%200%200%200%200%204.978v2.046c0%20.356.287.643.643.643h3.69v3.691c0%20.356.288.643.644.643h2.046a.641.641%200%200%200%20.643-.643v-3.69h3.691A.641.641%200%200%200%2012%207.022Z'%20id='b'/%3e%3c/defs%3e%3cuse%20fill='%23FF7E1B'%20fill-rule='nonzero'%20xlink:href='%23b'/%3e%3c/svg%3e";
const next = "data:image/svg+xml,%3csvg%20width='13'%20height='18'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='m2%201%208%208-8%208'%20stroke='%231D2026'%20stroke-width='3'%20fill='none'%20fill-rule='evenodd'/%3e%3c/svg%3e";
const previous = "data:image/svg+xml,%3csvg%20width='12'%20height='18'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M11%201%203%209l8%208'%20stroke='%231D2026'%20stroke-width='3'%20fill='none'%20fill-rule='evenodd'/%3e%3c/svg%3e";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let totalImages;
  let $page, $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  const productNameUrl = $page.url.pathname.substring(1);
  const productObj = productDatabase[productNameUrl];
  console.log(productObj.name);
  let thumbImagesDivs = [];
  let activeImage = productObj.img;
  let currentIndex = 0;
  let productQuantity = 1;
  let productName = productObj.name;
  let currentPrice = productObj.currentPrice;
  let previousPrice = productObj.previousPrice;
  totalImages = 1;
  $$unsubscribe_page();
  return `<main class="main"><section class="product-wrapper"><div class="container"><div class="product-images-wrapper"><div class="preview-image-wrapper"><img${add_attribute("src", activeImage, 0)} class="preview-image" alt="Product Image"> <div class="arrows hide-for-desktop"><div class="next" data-svelte-h="svelte-srsxsm"><img${add_attribute("src", next, 0)} alt="Next Icon"></div> <div class="prev" data-svelte-h="svelte-shi7ce"><img${add_attribute("src", previous, 0)} alt="Previous Icon"></div></div> <div class="count"><p><span class="current">${escape(currentIndex + 1)}</span> of
              <span class="total">${escape(totalImages)}</span></p></div></div> <div class="thumbs-wrapper hide-for-mobile">${each(thumbImagesDivs, (thumb, i) => {
    return `<div class="${["thumb-image", i === currentIndex ? "active" : ""].join(" ").trim()}"><img${add_attribute("src", thumb.src, 0)} alt="Product Thumb Image"> </div>`;
  })}</div></div> <div class="product-details-wrapper"><p class="product-brabd">${escape(productObj.compnay)}</p> <h1 class="product-title">${escape(productName)}</h1> <p class="product-description">${escape(productObj.description)}</p> <div class="product-price"><div class="current-price-wrapper"><h2 class="current-price">₹${escape(currentPrice)}</h2> <span class="discount">save ${escape(Math.floor(100 - currentPrice / previousPrice * 100))}%</span></div> <div class="previous-price-wrapper"><span class="previous-price">₹${escape(previousPrice)}</span></div></div> <form class="add-to-cart-form"><div class="product-quantity"><button type="button" class="button minus" data-svelte-h="svelte-15z6l8w"><img${add_attribute("src", minus, 0)} alt="Minus Icon"></button> <span class="product-quantity-num">${escape(productQuantity)}</span> <button type="button" class="button plus" data-svelte-h="svelte-mnjn7q"><img${add_attribute("src", plus, 0)} alt="Plus Icon"></button></div> <button type="submit" aria-label="Add to cart" class="button add-btn" data-svelte-h="svelte-x9ejin"><img src="./images/icon-cart.svg" alt="">
            Buy Now</button></form></div></div></section></main>  <div class="${["lightbox-wrapper", ""].join(" ").trim()}" data-svelte-h="svelte-1kl0a8b"><div class="lightbox-content"></div></div>  <div class="${["overlay", ""].join(" ").trim()}"></div>`;
});
export {
  Page as default
};
