import { d as dev } from "../../../../chunks/index3.js";
const csr = dev;
const prerender = true;
export {
  csr,
  prerender
};
