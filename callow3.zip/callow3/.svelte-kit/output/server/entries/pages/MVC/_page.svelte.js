import { c as create_ssr_component } from "../../../chunks/ssr.js";
function checkAddressAndRoute() {
  const userAddress = localStorage.getItem("userAddress");
  const userData = localStorage.getItem("mobile");
  if (!userAddress) {
    window.location.href = "../adderss";
  } else if (!userData) {
    window.location.href = "../login";
  } else {
    window.location.href = "../order";
  }
}
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  checkAddressAndRoute();
  return ``;
});
export {
  Page as default
};
