import { c as create_ssr_component, v as validate_component, d as each, a as add_attribute, e as escape } from "../../../chunks/ssr.js";
import { I as Icon } from "../../../chunks/Icon.js";
const Chevron_right = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [["path", { "d": "m9 18 6-6-6-6" }]];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "chevron-right" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const css$1 = {
  code: ".progress-container.svelte-denkad.svelte-denkad{display:flex;justify-content:space-between;align-items:center;width:100%;max-width:600px;margin-inline:auto;padding-top:10px}.step-link.svelte-denkad.svelte-denkad{text-decoration:none;color:inherit;flex:1}.step.svelte-denkad.svelte-denkad{display:flex;flex-direction:column;align-items:center}.step-circle.svelte-denkad.svelte-denkad{width:30px;height:30px;border-radius:50%;border:2px solid #ccc;display:flex;justify-content:center;align-items:center;font-size:14px;font-weight:bold;margin-bottom:5px}.step-text.svelte-denkad.svelte-denkad{font-size:14px;color:#666}.step.active.svelte-denkad .step-circle.svelte-denkad{border-color:#008080;color:#008080}.step.active.svelte-denkad .step-text.svelte-denkad{color:#008080}.step.completed.svelte-denkad .step-circle.svelte-denkad{background-color:#008080;border-color:#008080;color:white}.step-line.svelte-denkad.svelte-denkad{flex-grow:1;height:2px;background-color:#ccc;margin:0 10px}.step-line.active.svelte-denkad.svelte-denkad{background-color:#008080}",
  map: `{"version":3,"file":"step-progressbar.svelte","sources":["step-progressbar.svelte"],"sourcesContent":["<script>\\n  export let steps = [\\n    { label: 'Address', completed: true, link: '../adderss' },\\n    { label: 'Payment', completed: true, link: '#delivery' },\\n    { label: 'Order', completed: false, link: '#payment' },\\n  ];\\n export let currentStep = 3;\\n $: activeStep = steps[currentStep];\\n \\n function handleStepClick(index) {\\n   if (index <= currentStep) {\\n     currentStep = index;\\n   }\\n }\\n <\/script>\\n \\n <div class=\\"progress-container\\">\\n  {#each steps as step, index}\\n   <a href={step.link} class=\\"step-link\\">\\n     <div class=\\"step\\" class:completed={step.completed} class:active={index === currentStep}>\\n       <div class=\\"step-circle\\">\\n         {#if step.completed}\\n           ✓\\n         {:else if index === currentStep}\\n           <!-- Empty circle for current step -->\\n         {:else}\\n           <span>{index + 1}</span>\\n         {/if}\\n       </div>\\n       <div class=\\"step-text\\">{step.label}</div>\\n     </div>\\n   </a>\\n   {#if index < steps.length - 1}\\n     <div class=\\"step-line\\" class:active={index < currentStep}></div>\\n   {/if}\\n  {/each}\\n </div>\\n \\n <style>\\n .progress-container {\\n   display: flex;\\n   justify-content: space-between;\\n   align-items: center;\\n   width: 100%;\\n   max-width: 600px;\\n   margin-inline: auto;\\n   padding-top: 10px;\\n }\\n .step-link {\\n   text-decoration: none;\\n   color: inherit;\\n   flex: 1;\\n }\\n .step {\\n   display: flex;\\n   flex-direction: column;\\n   align-items: center;\\n }\\n .step-circle {\\n   width: 30px;\\n   height: 30px;\\n   border-radius: 50%;\\n   border: 2px solid #ccc;\\n   display: flex;\\n   justify-content: center;\\n   align-items: center;\\n   font-size: 14px;\\n   font-weight: bold;\\n   margin-bottom: 5px;\\n }\\n .step-text {\\n   font-size: 14px;\\n   color: #666;\\n }\\n .step.active .step-circle {\\n   border-color: #008080;\\n   color: #008080;\\n }\\n .step.active .step-text {\\n   color: #008080;\\n }\\n .step.completed .step-circle {\\n   background-color: #008080;\\n   border-color: #008080;\\n   color: white;\\n }\\n .step-line {\\n   flex-grow: 1;\\n   height: 2px;\\n   background-color: #ccc;\\n   margin: 0 10px;\\n }\\n .step-line.active {\\n   background-color: #008080;\\n }\\n </style>"],"names":[],"mappings":"AAuCC,+CAAoB,CAClB,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aAAa,CAC9B,WAAW,CAAE,MAAM,CACnB,KAAK,CAAE,IAAI,CACX,SAAS,CAAE,KAAK,CAChB,aAAa,CAAE,IAAI,CACnB,WAAW,CAAE,IACf,CACA,sCAAW,CACT,eAAe,CAAE,IAAI,CACrB,KAAK,CAAE,OAAO,CACd,IAAI,CAAE,CACR,CACA,iCAAM,CACJ,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MACf,CACA,wCAAa,CACX,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,IAAI,CACtB,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,SAAS,CAAE,IAAI,CACf,WAAW,CAAE,IAAI,CACjB,aAAa,CAAE,GACjB,CACA,sCAAW,CACT,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,IACT,CACA,KAAK,qBAAO,CAAC,0BAAa,CACxB,YAAY,CAAE,OAAO,CACrB,KAAK,CAAE,OACT,CACA,KAAK,qBAAO,CAAC,wBAAW,CACtB,KAAK,CAAE,OACT,CACA,KAAK,wBAAU,CAAC,0BAAa,CAC3B,gBAAgB,CAAE,OAAO,CACzB,YAAY,CAAE,OAAO,CACrB,KAAK,CAAE,KACT,CACA,sCAAW,CACT,SAAS,CAAE,CAAC,CACZ,MAAM,CAAE,GAAG,CACX,gBAAgB,CAAE,IAAI,CACtB,MAAM,CAAE,CAAC,CAAC,IACZ,CACA,UAAU,mCAAQ,CAChB,gBAAgB,CAAE,OACpB"}`
};
const Step_progressbar = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { steps = [
    {
      label: "Address",
      completed: true,
      link: "../adderss"
    },
    {
      label: "Payment",
      completed: true,
      link: "#delivery"
    },
    {
      label: "Order",
      completed: false,
      link: "#payment"
    }
  ] } = $$props;
  let { currentStep = 3 } = $$props;
  if ($$props.steps === void 0 && $$bindings.steps && steps !== void 0) $$bindings.steps(steps);
  if ($$props.currentStep === void 0 && $$bindings.currentStep && currentStep !== void 0) $$bindings.currentStep(currentStep);
  $$result.css.add(css$1);
  steps[currentStep];
  return `<div class="progress-container svelte-denkad">${each(steps, (step, index) => {
    return `<a${add_attribute("href", step.link, 0)} class="step-link svelte-denkad"><div class="${[
      "step svelte-denkad",
      (step.completed ? "completed" : "") + " " + (index === currentStep ? "active" : "")
    ].join(" ").trim()}"><div class="step-circle svelte-denkad">${step.completed ? `✓` : `${index === currentStep ? `` : `<span>${escape(index + 1)}</span>`}`}</div> <div class="step-text svelte-denkad">${escape(step.label)}</div> </div></a> ${index < steps.length - 1 ? `<div class="${["step-line svelte-denkad", index < currentStep ? "active" : ""].join(" ").trim()}"></div>` : ``}`;
  })} </div>`;
});
const css = {
  code: ".order-summary.svelte-lo1tqr.svelte-lo1tqr{max-width:600px;margin:1rem auto;background-color:white;padding:24px;border-radius:8px;box-shadow:0 1px 3px rgba(0, 0, 0, 0.1)}h2.svelte-lo1tqr.svelte-lo1tqr{font-size:24px;font-weight:bold;margin-bottom:16px}h3.svelte-lo1tqr.svelte-lo1tqr{font-weight:bold;margin-bottom:8px}.shipping-info.svelte-lo1tqr.svelte-lo1tqr{margin-bottom:16px;color:#666}.order-details.svelte-lo1tqr.svelte-lo1tqr{border-top:1px solid #e0e0e0;padding-top:16px;margin-bottom:16px}.detail-row.svelte-lo1tqr.svelte-lo1tqr{display:flex;justify-content:space-between;margin-bottom:8px}.total.svelte-lo1tqr.svelte-lo1tqr{font-weight:bold}.total.svelte-lo1tqr span.svelte-lo1tqr:last-child{color:#e53e3e}.savings.svelte-lo1tqr.svelte-lo1tqr{background-color:#fffbeb;padding:12px;border-radius:4px;margin-bottom:16px}.savings.svelte-lo1tqr p.svelte-lo1tqr{color:#e53e3e;font-weight:bold}.savings.svelte-lo1tqr ul.svelte-lo1tqr{list-style-type:disc;padding-left:20px}.payment-method.svelte-lo1tqr.svelte-lo1tqr,.delivery-address.svelte-lo1tqr.svelte-lo1tqr{margin-bottom:16px}.method-row.svelte-lo1tqr.svelte-lo1tqr,.address-row.svelte-lo1tqr.svelte-lo1tqr{display:flex;justify-content:space-between;align-items:center;border:1px solid #e0e0e0;padding:12px;border-radius:4px}.address-details.svelte-lo1tqr.svelte-lo1tqr{color:#666}.place-order-button.svelte-lo1tqr.svelte-lo1tqr{width:100%;background-color:#fbbf24;color:black;padding:12px;border:none;border-radius:4px;font-weight:bold;cursor:pointer}",
  map: `{"version":3,"file":"delivery.svelte","sources":["delivery.svelte"],"sourcesContent":["<script>\\n  import { ChevronRight } from 'lucide-svelte';\\n\\n  export let shippingAddress = 'Mer devraj bhai, A17-18, Shiv ...';\\n  export let items = 1;\\n  export let currentPrice = 0;\\n  export let previousPrice = 0;\\n  let subtotal = currentPrice * items;\\n  let delivery = 0;\\n  let orderTotal = subtotal + delivery;\\n  export let savings = (previousPrice - currentPrice)*items;\\n  let savingsPercentage = 100-(Math.floor((currentPrice/previousPrice)*100));\\n\\n  function place() {\\n    window.location.href = '../experiment2'\\n  }\\n<\/script>\\n\\n<div class=\\"order-summary\\">\\n  <h2>Order now</h2>\\n  \\n  <div class=\\"shipping-info\\">\\n    <p>Shipping to: <span style=\\"font-weight: bold;color:red;\\">{shippingAddress}</span></p>\\n  </div>\\n  \\n  <div class=\\"order-details\\">\\n    <div class=\\"detail-row\\">\\n      <span>Subtotal ({items} item):</span>\\n      <span>₹{subtotal}</span>\\n    </div>\\n    <div class=\\"detail-row\\">\\n      <span>Delivery:</span>\\n      <span>₹{delivery}</span>\\n    </div>\\n    <div class=\\"detail-row total\\">\\n      <span>Order Total:</span>\\n      <span>₹{orderTotal}</span>\\n    </div>\\n  </div>\\n  \\n  <div class=\\"savings\\">\\n    <p>Your Savings: ₹ {savings.toFixed(2)} ({savingsPercentage}%)</p>\\n    <ul>\\n      <li>Item discount</li>\\n    </ul>\\n  </div>\\n  \\n  <div class=\\"payment-method\\">\\n    <h3>Pay with</h3>\\n    <div class=\\"method-row\\">\\n      <span>Pay on delivery (Cash/Card)</span>\\n      <ChevronRight size={20} />\\n    </div>\\n  </div>\\n  \\n \\n  \\n  <div class=\\"delivery-address\\">\\n    <h3>Deliver to</h3>\\n    <div class=\\"address-row\\">\\n      <div>\\n        <p>Mer devraj bhai</p>\\n        <p class=\\"address-details\\">A17-18, Shiv Apartment Javahar Society, L.h ...</p>\\n      </div>\\n      <ChevronRight size={20} />\\n    </div>\\n  </div>\\n  \\n  <button class=\\"place-order-button\\" on:click={place}>Place your order</button>\\n</div>\\n\\n<style>\\n  .order-summary {\\n    /* min-width: 400px; */\\n    max-width: 600px;\\n    margin: 1rem auto;\\n    background-color: white;\\n    padding: 24px;\\n    border-radius: 8px;\\n    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);\\n  }\\n\\n  h2 {\\n    font-size: 24px;\\n    font-weight: bold;\\n    margin-bottom: 16px;\\n  }\\n\\n  h3 {\\n    font-weight: bold;\\n    margin-bottom: 8px;\\n  }\\n\\n  .shipping-info {\\n    margin-bottom: 16px;\\n    color: #666;\\n  }\\n\\n  .order-details {\\n    border-top: 1px solid #e0e0e0;\\n    padding-top: 16px;\\n    margin-bottom: 16px;\\n  }\\n\\n  .detail-row {\\n    display: flex;\\n    justify-content: space-between;\\n    margin-bottom: 8px;\\n  }\\n\\n  .total {\\n    font-weight: bold;\\n  }\\n\\n  .total span:last-child {\\n    color: #e53e3e;\\n  }\\n\\n  .savings {\\n    background-color: #fffbeb;\\n    padding: 12px;\\n    border-radius: 4px;\\n    margin-bottom: 16px;\\n  }\\n\\n  .savings p {\\n    color: #e53e3e;\\n    font-weight: bold;\\n  }\\n\\n  .savings ul {\\n    list-style-type: disc;\\n    padding-left: 20px;\\n  }\\n\\n  .payment-method, .delivery-address {\\n    margin-bottom: 16px;\\n  }\\n\\n  .method-row, .address-row {\\n    display: flex;\\n    justify-content: space-between;\\n    align-items: center;\\n    border: 1px solid #e0e0e0;\\n    padding: 12px;\\n    border-radius: 4px;\\n  }\\n\\n  .address-details {\\n    color: #666;\\n  }\\n\\n  .place-order-button {\\n    width: 100%;\\n    background-color: #fbbf24;\\n    color: black;\\n    padding: 12px;\\n    border: none;\\n    border-radius: 4px;\\n    font-weight: bold;\\n    cursor: pointer;\\n  }\\n</style>"],"names":[],"mappings":"AAwEE,0CAAe,CAEb,SAAS,CAAE,KAAK,CAChB,MAAM,CAAE,IAAI,CAAC,IAAI,CACjB,gBAAgB,CAAE,KAAK,CACvB,OAAO,CAAE,IAAI,CACb,aAAa,CAAE,GAAG,CAClB,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,GAAG,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CACzC,CAEA,8BAAG,CACD,SAAS,CAAE,IAAI,CACf,WAAW,CAAE,IAAI,CACjB,aAAa,CAAE,IACjB,CAEA,8BAAG,CACD,WAAW,CAAE,IAAI,CACjB,aAAa,CAAE,GACjB,CAEA,0CAAe,CACb,aAAa,CAAE,IAAI,CACnB,KAAK,CAAE,IACT,CAEA,0CAAe,CACb,UAAU,CAAE,GAAG,CAAC,KAAK,CAAC,OAAO,CAC7B,WAAW,CAAE,IAAI,CACjB,aAAa,CAAE,IACjB,CAEA,uCAAY,CACV,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aAAa,CAC9B,aAAa,CAAE,GACjB,CAEA,kCAAO,CACL,WAAW,CAAE,IACf,CAEA,oBAAM,CAAC,kBAAI,WAAY,CACrB,KAAK,CAAE,OACT,CAEA,oCAAS,CACP,gBAAgB,CAAE,OAAO,CACzB,OAAO,CAAE,IAAI,CACb,aAAa,CAAE,GAAG,CAClB,aAAa,CAAE,IACjB,CAEA,sBAAQ,CAAC,eAAE,CACT,KAAK,CAAE,OAAO,CACd,WAAW,CAAE,IACf,CAEA,sBAAQ,CAAC,gBAAG,CACV,eAAe,CAAE,IAAI,CACrB,YAAY,CAAE,IAChB,CAEA,2CAAe,CAAE,6CAAkB,CACjC,aAAa,CAAE,IACjB,CAEA,uCAAW,CAAE,wCAAa,CACxB,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aAAa,CAC9B,WAAW,CAAE,MAAM,CACnB,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,OAAO,CACzB,OAAO,CAAE,IAAI,CACb,aAAa,CAAE,GACjB,CAEA,4CAAiB,CACf,KAAK,CAAE,IACT,CAEA,+CAAoB,CAClB,KAAK,CAAE,IAAI,CACX,gBAAgB,CAAE,OAAO,CACzB,KAAK,CAAE,KAAK,CACZ,OAAO,CAAE,IAAI,CACb,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,WAAW,CAAE,IAAI,CACjB,MAAM,CAAE,OACV"}`
};
let delivery = 0;
const Delivery = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { shippingAddress = "Mer devraj bhai, A17-18, Shiv ..." } = $$props;
  let { items = 1 } = $$props;
  let { currentPrice = 0 } = $$props;
  let { previousPrice = 0 } = $$props;
  let subtotal = currentPrice * items;
  let orderTotal = subtotal + delivery;
  let { savings = (previousPrice - currentPrice) * items } = $$props;
  let savingsPercentage = 100 - Math.floor(currentPrice / previousPrice * 100);
  if ($$props.shippingAddress === void 0 && $$bindings.shippingAddress && shippingAddress !== void 0) $$bindings.shippingAddress(shippingAddress);
  if ($$props.items === void 0 && $$bindings.items && items !== void 0) $$bindings.items(items);
  if ($$props.currentPrice === void 0 && $$bindings.currentPrice && currentPrice !== void 0) $$bindings.currentPrice(currentPrice);
  if ($$props.previousPrice === void 0 && $$bindings.previousPrice && previousPrice !== void 0) $$bindings.previousPrice(previousPrice);
  if ($$props.savings === void 0 && $$bindings.savings && savings !== void 0) $$bindings.savings(savings);
  $$result.css.add(css);
  return `<div class="order-summary svelte-lo1tqr"><h2 class="svelte-lo1tqr" data-svelte-h="svelte-19dcxme">Order now</h2> <div class="shipping-info svelte-lo1tqr"><p>Shipping to: <span style="font-weight: bold;color:red;">${escape(shippingAddress)}</span></p></div> <div class="order-details svelte-lo1tqr"><div class="detail-row svelte-lo1tqr"><span>Subtotal (${escape(items)} item):</span> <span>₹${escape(subtotal)}</span></div> <div class="detail-row svelte-lo1tqr"><span data-svelte-h="svelte-18py74w">Delivery:</span> <span>₹${escape(delivery)}</span></div> <div class="detail-row total svelte-lo1tqr"><span class="svelte-lo1tqr" data-svelte-h="svelte-2drnoe">Order Total:</span> <span class="svelte-lo1tqr">₹${escape(orderTotal)}</span></div></div> <div class="savings svelte-lo1tqr"><p class="svelte-lo1tqr">Your Savings: ₹ ${escape(savings.toFixed(2))} (${escape(savingsPercentage)}%)</p> <ul class="svelte-lo1tqr" data-svelte-h="svelte-1h3koxf"><li>Item discount</li></ul></div> <div class="payment-method svelte-lo1tqr"><h3 class="svelte-lo1tqr" data-svelte-h="svelte-1gtk8zu">Pay with</h3> <div class="method-row svelte-lo1tqr"><span data-svelte-h="svelte-1bd889m">Pay on delivery (Cash/Card)</span> ${validate_component(Chevron_right, "ChevronRight").$$render($$result, { size: 20 }, {}, {})}</div></div> <div class="delivery-address svelte-lo1tqr"><h3 class="svelte-lo1tqr" data-svelte-h="svelte-13kiaee">Deliver to</h3> <div class="address-row svelte-lo1tqr"><div data-svelte-h="svelte-1pov28y"><p>Mer devraj bhai</p> <p class="address-details svelte-lo1tqr">A17-18, Shiv Apartment Javahar Society, L.h ...</p></div> ${validate_component(Chevron_right, "ChevronRight").$$render($$result, { size: 20 }, {}, {})}</div></div> <button class="place-order-button svelte-lo1tqr" data-svelte-h="svelte-1c9nyyz">Place your order</button> </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let prodcutObj = JSON.parse(sessionStorage.getItem("userData"));
  const userAddress = localStorage.getItem("userAddress");
  return `${validate_component(Step_progressbar, "Progress").$$render($$result, {}, {}, {})} ${prodcutObj ? `${validate_component(Delivery, "Delivery").$$render(
    $$result,
    {
      shippingAddress: userAddress,
      items: prodcutObj.items,
      currentPrice: prodcutObj.currentPrice,
      previousPrice: prodcutObj.previousPrice
    },
    {},
    {}
  )}` : ``}`;
});
export {
  Page as default
};
