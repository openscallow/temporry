import { c as create_ssr_component, d as each, a as add_attribute, e as escape, v as validate_component } from "../../chunks/ssr.js";
import { p as productDatabase } from "../../chunks/product.js";
const css = {
  code: ".container.svelte-x6t930.svelte-x6t930{display:grid;gap:1rem;margin:1rem;grid-template-columns:repeat(auto-fill, minmax(150px, 1fr))}.tile.svelte-x6t930.svelte-x6t930{display:flex;flex-direction:column;align-items:center;padding:1.5rem;background-color:#f0f0f0;border-radius:8px;transition:transform 0.3s ease, box-shadow 0.3s ease}.tile.svelte-x6t930.svelte-x6t930:hover{transform:translateY(-5px);box-shadow:0 4px 10px rgba(0, 0, 0, 0.1)}.tile.svelte-x6t930 a.svelte-x6t930{text-decoration:none;color:inherit;text-align:center}.tile.svelte-x6t930 img.svelte-x6t930{width:100%;max-width:150px;height:auto;margin-bottom:1rem}.tile.svelte-x6t930 h2.svelte-x6t930{font-size:1.2rem;margin:0}",
  map: `{"version":3,"file":"grid-tiels.svelte","sources":["grid-tiels.svelte"],"sourcesContent":["<script>\\n  import { onMount } from 'svelte';\\n  import {productDatabase} from '$lib/json/product.js';\\n  console.log(productDatabase[0])\\n\\n\\n  // console.log(productDatabase.map(itemss => ({\\n  //   edff:itemss.img\\n  // })));\\n\\n  let products = [\\n    {img: productDatabase[0].img,\\n     link: \`./\${productDatabase[0].id}\`,\\n     name: productDatabase[0].name\\n    }]\\n  console.log(products[0].link)\\n\\n\\n  onMount();\\n\\n \\n  <\/script>\\n  \\n  <div class=\\"container\\">\\n    {#each products as product}\\n      <div class=\\"tile\\">\\n        <a href={product.link} rel=\\"noopener noreferrer\\">\\n          <img src={product.img} alt={product.name} />\\n          <h2>{product.name}</h2>\\n        </a>\\n      </div>\\n    {/each}\\n  </div>\\n  \\n  <style>\\n    .container {\\n      display: grid;\\n      gap: 1rem;\\n      margin: 1rem;\\n      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));\\n    }\\n  \\n    .tile {\\n      display: flex;\\n      flex-direction: column;\\n      align-items: center;\\n      padding: 1.5rem;\\n      background-color: #f0f0f0;\\n      border-radius: 8px;\\n      transition: transform 0.3s ease, box-shadow 0.3s ease;\\n    }\\n  \\n    .tile:hover {\\n      transform: translateY(-5px);\\n      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);\\n    }\\n  \\n    .tile a {\\n      text-decoration: none;\\n      color: inherit;\\n      text-align: center;\\n    }\\n  \\n    .tile img {\\n      width: 100%;\\n      max-width: 150px;\\n      height: auto;\\n      margin-bottom: 1rem;\\n    }\\n  \\n    .tile h2 {\\n      font-size: 1.2rem;\\n      margin: 0;\\n    }\\n  </style>"],"names":[],"mappings":"AAmCI,sCAAW,CACT,OAAO,CAAE,IAAI,CACb,GAAG,CAAE,IAAI,CACT,MAAM,CAAE,IAAI,CACZ,qBAAqB,CAAE,OAAO,SAAS,CAAC,CAAC,OAAO,KAAK,CAAC,CAAC,GAAG,CAAC,CAC7D,CAEA,iCAAM,CACJ,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MAAM,CACnB,OAAO,CAAE,MAAM,CACf,gBAAgB,CAAE,OAAO,CACzB,aAAa,CAAE,GAAG,CAClB,UAAU,CAAE,SAAS,CAAC,IAAI,CAAC,IAAI,CAAC,CAAC,UAAU,CAAC,IAAI,CAAC,IACnD,CAEA,iCAAK,MAAO,CACV,SAAS,CAAE,WAAW,IAAI,CAAC,CAC3B,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,IAAI,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAC1C,CAEA,mBAAK,CAAC,eAAE,CACN,eAAe,CAAE,IAAI,CACrB,KAAK,CAAE,OAAO,CACd,UAAU,CAAE,MACd,CAEA,mBAAK,CAAC,iBAAI,CACR,KAAK,CAAE,IAAI,CACX,SAAS,CAAE,KAAK,CAChB,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,IACjB,CAEA,mBAAK,CAAC,gBAAG,CACP,SAAS,CAAE,MAAM,CACjB,MAAM,CAAE,CACV"}`
};
const Grid_tiels = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  console.log(productDatabase[0]);
  let products = [
    {
      img: productDatabase[0].img,
      link: `./${productDatabase[0].id}`,
      name: productDatabase[0].name
    }
  ];
  console.log(products[0].link);
  $$result.css.add(css);
  return `<div class="container svelte-x6t930">${each(products, (product) => {
    return `<div class="tile svelte-x6t930"><a${add_attribute("href", product.link, 0)} rel="noopener noreferrer" class="svelte-x6t930"><img${add_attribute("src", product.img, 0)}${add_attribute("alt", product.name, 0)} class="svelte-x6t930"> <h2 class="svelte-x6t930">${escape(product.name)}</h2></a> </div>`;
  })} </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${$$result.head += `<!-- HEAD_svelte-rl5k2i_START -->${$$result.title = `<title>Home</title>`, ""}<meta name="description" content="Callow"><!-- HEAD_svelte-rl5k2i_END -->`, ""} ${validate_component(Grid_tiels, "Tiels").$$render($$result, {}, {}, {})}`;
});
export {
  Page as default
};
