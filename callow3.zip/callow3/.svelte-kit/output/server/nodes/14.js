import * as server from '../entries/pages/sverdle/_page.server.js';

export const index = 14;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/sverdle/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/sverdle/+page.server.js";
export const imports = ["_app/immutable/nodes/14.Dt1zB1qD.js","_app/immutable/chunks/scheduler.DhMJ2Xpz.js","_app/immutable/chunks/index.C8k5DeId.js","_app/immutable/chunks/each.DbImng9I.js","_app/immutable/chunks/entry.C3y0jMeI.js"];
export const stylesheets = ["_app/immutable/assets/14.DOkkq0IA.css"];
export const fonts = [];
