

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_slug_/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.CoV2-Amk.js","_app/immutable/chunks/scheduler.DhMJ2Xpz.js","_app/immutable/chunks/index.C8k5DeId.js","_app/immutable/chunks/each.DbImng9I.js","_app/immutable/chunks/stores.CAgb2agO.js","_app/immutable/chunks/entry.C3y0jMeI.js","_app/immutable/chunks/product.BeuP5DaG.js"];
export const stylesheets = ["_app/immutable/assets/5.Dapzyug-.css","_app/immutable/assets/app.BdeOKIbd.css"];
export const fonts = ["_app/immutable/assets/fira-mono-cyrillic-ext-400-normal.B04YIrm4.woff2","_app/immutable/assets/fira-mono-all-400-normal.B2mvLtSD.woff","_app/immutable/assets/fira-mono-cyrillic-400-normal.36-45Uyg.woff2","_app/immutable/assets/fira-mono-greek-ext-400-normal.CsqI23CO.woff2","_app/immutable/assets/fira-mono-greek-400-normal.C3zng6O6.woff2","_app/immutable/assets/fira-mono-latin-ext-400-normal.D6XfiR-_.woff2","_app/immutable/assets/fira-mono-latin-400-normal.DKjLVgQi.woff2"];
