import * as universal from '../entries/pages/_page.js';

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+page.js";
export const imports = ["_app/immutable/nodes/2.ErORUbL1.js","_app/immutable/chunks/scheduler.DhMJ2Xpz.js","_app/immutable/chunks/index.C8k5DeId.js","_app/immutable/chunks/each.DbImng9I.js","_app/immutable/chunks/product.BeuP5DaG.js"];
export const stylesheets = ["_app/immutable/assets/2.C-oS1ogV.css"];
export const fonts = [];
