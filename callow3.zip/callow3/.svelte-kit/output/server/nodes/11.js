import * as universal from '../entries/pages/order/_page.js';

export const index = 11;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/order/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/order/+page.js";
export const imports = ["_app/immutable/nodes/11.7EdDA5zM.js","_app/immutable/chunks/scheduler.DhMJ2Xpz.js","_app/immutable/chunks/index.C8k5DeId.js","_app/immutable/chunks/each.DbImng9I.js","_app/immutable/chunks/Icon.BD_qnYyM.js"];
export const stylesheets = ["_app/immutable/assets/11.aypITVTy.css"];
export const fonts = [];
