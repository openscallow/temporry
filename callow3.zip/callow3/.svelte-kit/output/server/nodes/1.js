

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1._aknnoNF.js","_app/immutable/chunks/scheduler.DhMJ2Xpz.js","_app/immutable/chunks/index.C8k5DeId.js","_app/immutable/chunks/stores.CAgb2agO.js","_app/immutable/chunks/entry.C3y0jMeI.js"];
export const stylesheets = [];
export const fonts = [];
