

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/adderss/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/7.Z0PdaQ_M.js","_app/immutable/chunks/scheduler.DhMJ2Xpz.js","_app/immutable/chunks/index.C8k5DeId.js","_app/immutable/chunks/each.DbImng9I.js","_app/immutable/chunks/Icon.BD_qnYyM.js"];
export const stylesheets = ["_app/immutable/assets/7.DBdf3t10.css"];
export const fonts = [];
