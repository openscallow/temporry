let productDatabase = {
  0: {
    img: "https://m.media-amazon.com/images/I/81VadRn+t-L._SX679_.jpg",
    compnay: "Kangaro",
    name: "kangaro stapler no.10",
    description: "This stapler features an all-steel construction with a built-in staple remover and reload indicator. It uses No.10 staples, with a loading capacity of 50 staples and can staple up to 20 sheets of 75-80 gsm paper. The stapler has a 52mm throat depth, is manually loaded, supports conventional stapling, and includes a tacking function.",
    currentPrice: 70,
    previousPrice: 75,
    id: 0
  }
};
export {
  productDatabase as p
};
