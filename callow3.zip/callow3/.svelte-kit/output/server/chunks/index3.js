import { D as DEV } from "./prod-ssr.js";
const dev = DEV;
export {
  dev as d
};
