import{b as a}from"../chunks/entry.C3y0jMeI.js";export{a as start};
