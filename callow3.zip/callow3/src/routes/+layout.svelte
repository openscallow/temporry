<script>
	import Navbar from '../lib/components/navbar.svelte';
	import '../app.css'
</script>
<Navbar />

<slot></slot>

