<script>
	import Tiels from '../lib/components/grid-tiels.svelte';
</script>

<svelte:head>
	<title>Home</title>
	<meta name="description" content="Callow" />
</svelte:head>
<Tiels />
